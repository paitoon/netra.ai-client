from enum import Enum

class HttpMethod(Enum):
    POST = 1
    GET = 2
    PUT = 3
    DELETE = 4
